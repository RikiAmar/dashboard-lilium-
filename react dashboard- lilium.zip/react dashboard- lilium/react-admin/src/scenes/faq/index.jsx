import { Box, useTheme, Typography } from "@mui/material"; //לשאול מה זה היוז
import Header from "../../components/Header";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { tokens } from "../../theme";

const FAQ = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <Box m="20px" >
      <Header title="FAQ" subtitle="Frequently Asked Questions Page" />
{/* הוספה של קו מפריד  */}

      <Accordion sx={{ borderBottom: '1px solid #CCCCCC', boxShadow: 'none'  }} >
        <AccordionSummary  expandIcon={<ExpandMoreIcon sx={{ transform: 'rotate(-90deg)' }} />} >
        <Typography sx={{ fontWeight: 'bold', paddingTop: "30px" }} variant="h5" >
            An Important Question
          </Typography>
        </AccordionSummary>
        <AccordionDetails sx={{paddingBottom:"19px"}}  >
          <Typography sx={{ color: '#444041' }}>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod
            expedita laborum vitae nihil officia eius, velit laboriosam nostrum
            nisi. Ea suscipit aliquid perferendis error animi ad ex nostrum
            aspernatur necessitatibus.
          </Typography>
        </AccordionDetails>
      </Accordion>
  
      <Accordion sx={{ borderBottom: '1px solid #CCCCCC', boxShadow: 'none' }} >
      <AccordionSummary  expandIcon={<ExpandMoreIcon sx={{ transform: 'rotate(-90deg)' }} />}>
      <Typography sx={{ fontWeight: 'bold', paddingTop: "30px" }} variant="h5" >
            Another Important Question
          </Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ padding: '16px', marginBottom: '16px' }} >
          <Typography sx={{ color: '#444041' }}>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod
            expedita laborum vitae nihil officia eius, velit laboriosam nostrum
            nisi. Ea suscipit aliquid perferendis error animi ad ex nostrum
            aspernatur necessitatibus.
          </Typography>
        </AccordionDetails>
      </Accordion>

      
      <Accordion sx={{ borderBottom: '1px solid #CCCCCC', boxShadow: 'none' }} >
      <AccordionSummary  expandIcon={<ExpandMoreIcon sx={{ transform: 'rotate(-90deg)' }} />}>
      <Typography sx={{ fontWeight: 'bold', paddingTop: "30px" }} variant="h5" >            Your Favorite Question
          </Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ padding: '16px', marginBottom: '16px' }} >
          <Typography sx={{ color: '#444041' }}>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod
            expedita laborum vitae nihil officia eius, velit laboriosam nostrum
            nisi. Ea suscipit aliquid perferendis error animi ad ex nostrum
            aspernatur necessitatibus.
          </Typography>
        </AccordionDetails>
      </Accordion>

      
      <Accordion sx={{ borderBottom: '1px solid #CCCCCC', boxShadow: 'none' }} >
      <AccordionSummary  expandIcon={<ExpandMoreIcon sx={{ transform: 'rotate(-90deg)' }} />}>
      <Typography sx={{ fontWeight: 'bold', paddingTop: "30px" }} variant="h5" >            Some Random Question
          </Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ padding: '16px', marginBottom: '16px' }} >
          <Typography sx={{ color: '#444041' }}>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod
            expedita laborum vitae nihil officia eius, velit laboriosam nostrum
            nisi. Ea suscipit aliquid perferendis error animi ad ex nostrum
            aspernatur necessitatibus.
          </Typography>
        </AccordionDetails>
      </Accordion>

      
      <Accordion sx={{ borderBottom: '1px solid #CCCCCC', boxShadow: 'none' }} >
      <AccordionSummary  expandIcon={<ExpandMoreIcon sx={{ transform: 'rotate(-90deg)' }} />}>
      <Typography sx={{ fontWeight: 'bold', paddingTop: "30px" }} variant="h5" >
                The Final Question
          </Typography>
        </AccordionSummary>
        <AccordionDetails sx={{ padding: '16px', marginBottom: '16px' }} >
          <Typography sx={{ color: '#444041' }}>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod
            expedita laborum vitae nihil officia eius, velit laboriosam nostrum
            nisi. Ea suscipit aliquid perferendis error animi ad ex nostrum
            aspernatur necessitatibus.
          </Typography>
        </AccordionDetails>
      </Accordion>
    </Box>
  );
};

export default FAQ;
