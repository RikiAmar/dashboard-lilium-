import {
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  Select,
  TextField,
  Typography,
  MenuItem,
  Autocomplete,
  ToggleButton,
  Stack,
  ListItem,
  FormControl,
  InputLabel,
} from "@mui/material";
import { Formik } from "formik";
import * as yup from "yup";
import useMediaQuery from "@mui/material/useMediaQuery";
import Header from "../../components/Header";
import SaveOutlinedIcon from "@mui/icons-material/SaveOutlined";
import { useState } from "react";
import { mockSports } from "../../data/mockSports";
// import DatePicker from "@mui/lab/DatePicker";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const Form = () => {
  const isNonMobile = useMediaQuery("(min-width:600px)");
  const [selectedSports, setSelectedSports] = useState([]);
  const [selectedBestSports, setSelectedBestSports] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [day, setDay] = useState("");
  const [month, setMonth] = useState("");
  const [year, setYear] = useState("");

  const handleFormSubmit = (values) => {
    const isValidDate = validateDate(day, month, year);
    if (!isValidDate) {
      alert("Please enter a valid date.");
      return;
    }

    console.log({
      ...values,
      sportsPreferences: selectedSports,
      bestSports: selectedBestSports,
      dateOfBirth: `${day}-${month}-${year}`,
      additionalDate: selectedDate,
    });
  };

  const validateDate = (day, month, year) => {
    // Check if the day, month, and year are valid
    if (
      isNaN(day) ||
      isNaN(month) ||
      isNaN(year) ||
      day < 1 ||
      day > 31 ||
      month < 1 ||
      month > 12 ||
      year < 1900 ||
      year > new Date().getFullYear()
    ) {
      return false;
    }

    // Additional checks can be added here if needed

    return true;
  };

  const handleDateChange = (date) => {
    const day = date.getDate();
    const month = date.getMonth() + 1; // month is zero-basedינואר מיוצג 0 ודצמבר 11 לכן
    const year = date.getFullYear();

    setDay(day);
    setMonth(month);
    setYear(year);
    setSelectedDate(date);
  };

  const handleToggleChange = (value) => {
    if (selectedSports.includes(value)) {
      //בודק אם הערך ששונה כבר קיים במערך
      setSelectedSports(selectedSports.filter((sport) => sport !== value));
    } else {
      if (selectedSports.length < 3) {
        setSelectedSports([...selectedSports, value]);
      }
    }
  };

  return (
    <Box m="20px">
      <Header title="CREATE USER" subtitle="Create a New User Profile" />

      <Formik
        onSubmit={handleFormSubmit}
        initialValues={initialValues}
        validationSchema={checkoutSchema}
      >
        {({
          values,
          errors,
          touched,
          handleBlur,
          handleChange,
          handleSubmit,
        }) => (
          <form onSubmit={handleSubmit}>
            <Box
              display="grid"
              gap="5px"
              gridTemplateColumns="repeat(4, minmax(0, 1fr))"
              sx={{
                "& > div": { gridColumn: isNonMobile ? undefined : "span 4" },
              }}
            >
              <Box sx={{ gridColumn: "span 2" }}>
                <Typography
                  variant="subtitle1"
                  sx={{ mb: 1, fontWeight: "bold" }}
                >
                  First Name
                </Typography>
                <TextField
                  fullWidth
                  type="text"
                  label="First Name"
                  onBlur={handleBlur}
                  onChange={handleChange}
                  value={values.firstName}
                  name="firstName"
                  error={!!touched.firstName && !!errors.firstName}
                  helperText={touched.firstName && errors.firstName}
                  sx={{ gridColumn: "span 2" }}
                />
              </Box>

              <Box sx={{ gridColumn: "span 2" }}>
                <Typography
                  variant="subtitle1"
                  sx={{ mb: 1, fontWeight: "bold" }}
                >
                  Last Name
                </Typography>
                <TextField
                  fullWidth
                  type="text"
                  label="Last Name"
                  onBlur={handleBlur}
                  onChange={handleChange}
                  value={values.lastName}
                  name="lastName"
                  error={!!touched.lastName && !!errors.lastName}
                  helperText={touched.lastName && errors.lastName}
                  sx={{ gridColumn: "span 2" }}
                />
              </Box>

              <Box sx={{ gridColumn: "span 4" }}>
                <Typography
                  variant="subtitle1"
                  sx={{ mb: 1, fontWeight: "bold" }}
                >
                  Email
                </Typography>
                <TextField
                  fullWidth
                  type="text"
                  label="Email"
                  onBlur={handleBlur}
                  onChange={handleChange}
                  value={values.email}
                  name="email"
                  error={!!touched.email && !!errors.email}
                  helperText={touched.email && errors.email}
                  sx={{ gridColumn: "span 4" }}
                />
              </Box>

              <Box sx={{ gridColumn: "span 4" }}>
                <Typography
                  variant="subtitle1"
                  sx={{ mb: 1, fontWeight: "bold" }}
                >
                  Contact Number
                </Typography>
                <TextField
                  fullWidth
                  type="text"
                  label="Contact Number"
                  onBlur={handleBlur}
                  onChange={handleChange}
                  value={values.contact}
                  name="contact"
                  error={!!touched.contact && !!errors.contact}
                  helperText={touched.contact && errors.contact}
                  sx={{ gridColumn: "span 4" }}
                />
              </Box>

              <Box sx={{ gridColumn: "span 4" }}>
                <Typography
                  variant="subtitle1"
                  sx={{ mb: 1, fontWeight: "bold" }}
                >
                  Address 1
                </Typography>
                <TextField
                  fullWidth
                  type="text"
                  label="Address 1"
                  onBlur={handleBlur}
                  onChange={handleChange}
                  value={values.address1}
                  name="address1"
                  error={!!touched.address1 && !!errors.address1}
                  helperText={touched.address1 && errors.address1}
                  sx={{ gridColumn: "span 4" }}
                />
              </Box>

              <Box sx={{ gridColumn: "span 4" }}>
                <Typography
                  variant="subtitle1"
                  sx={{ mb: 1, fontWeight: "bold" }}
                >
                  Address 2
                </Typography>
                <TextField
                  fullWidth
                  type="text"
                  label="Address 2"
                  onBlur={handleBlur}
                  onChange={handleChange}
                  value={values.address2}
                  name="address2"
                  error={!!touched.address2 && !!errors.address2}
                  helperText={touched.address2 && errors.address2}
                  sx={{ gridColumn: "span 4" }}
                />
              </Box>
              {/*  1  שדה  */}
              <Box sx={{ gridColumn: "span 4" }}>
                <Typography
                  variant="subtitle1"
                  sx={{ mb: 1, fontWeight: "bold" }}
                >
                  User Sports Preferences
                </Typography>
                <Stack direction="row" spacing={1}>
                  {mockSports.map((sport) => (
                    <ToggleButton
                      key={sport}
                      value={sport}
                      selected={selectedSports.includes(sport)}
                      onClick={() => handleToggleChange(sport)}
                      sx={{ borderRadius: "20px" }}
                    >
                      {sport}
                    </ToggleButton>
                  ))}
                </Stack>
              </Box>

              {/*2 הוספת שדה  */}
              <Box sx={{ gridColumn: "span 4" }}>
                <Typography
                  variant="subtitle1"
                  sx={{ mb: 1, fontWeight: "bold" }}
                >
                  User Best Sports
                </Typography>
                <Autocomplete
                  multiple
                  id="user-best-sports"
                  options={mockSports}
                  value={selectedBestSports}
                  onChange={(event, newValue) => {
                    setSelectedBestSports(newValue);
                  }}
                  filterOptions={(options, { inputValue }) =>
                    options.filter((option) =>
                      option.toLowerCase().includes(inputValue.toLowerCase())
                    )
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Choose Your Best Sports"
                      fullWidth
                    />
                  )}
                />
              </Box>
              {/*3 תאריך לידה הוספת שדה  */}
              <Box sx={{ gridColumn: "span 4" }}>
                <Typography
                  variant="subtitle1"
                  sx={{ mb: 1, fontWeight: "bold" }}
                >
                  Date of Birth
                </Typography>
                <Box display="flex" alignItems="center">
                  <Box sx={{ mr: 1 }}>
                    <Typography
                      variant="subtitle1"
                      sx={{ mb: 1, fontWeight: "bold" }}
                    >
                      Day
                    </Typography>
                    <TextField
                      type="number"
                      placeholder="DD"
                      InputProps={{ inputProps: { min: 1, max: 31 } }}
                      value={day}
                      onChange={(e) => setDay(e.target.value)}
                    />
                  </Box>
                  <Box sx={{ mr: 1 }}>
                    <Typography
                      variant="subtitle1"
                      sx={{ mb: 1, fontWeight: "bold" }}
                    >
                      Month
                    </Typography>
                    <TextField
                      type="number"
                      placeholder="MM"
                      InputProps={{ inputProps: { min: 1, max: 12 } }}
                      value={month}
                      onChange={(e) => setMonth(e.target.value)}
                    />
                  </Box>
                  <Box>
                    <Typography
                      variant="subtitle1"
                      sx={{ mb: 1, fontWeight: "bold" }}
                    >
                      Year
                    </Typography>
                    <TextField
                      type="number"
                      placeholder="YYYY"
                      InputProps={{
                        inputProps: {
                          min: 1900,
                          max: new Date().getFullYear(),
                        },
                      }}
                      value={year}
                      onChange={(e) => setYear(e.target.value)}
                    />
                  </Box>
                  <Box sx={{ gridColumn: "span 4", ml: 4, mb: 3 }}>
                    <Typography
                      variant="subtitle1"
                      sx={{ fontWeight: "bold", mb: 2 }}
                    >
                      Pick date
                    </Typography>
                    <DatePicker
                      selected={selectedDate}
                      onChange={handleDateChange}
                      label="Additional Date"
                      value={selectedDate}
                      renderInput={(params) => <TextField {...params} />}
                    />
                  </Box>
                </Box>
              </Box>
            </Box>
            <Box display="flex" justifyContent="end" mt="20px">
              <Button type="submit" color="secondary" variant="contained"
                // sx={{ bgcolor: 'rgba(0, 0, 0, 0.6)', '&:hover': { bgcolor: 'rgba(0, 0, 0, 0.8)' } }}
                >
                <SaveOutlinedIcon /> Save Information
              </Button>
            </Box>
          </form>
        )}
      </Formik>
    </Box>
  );
};

const phoneRegExp =
  /^((\+[1-9]{1,4}[ -]?)|(\([0-9]{2,3}\)[ -]?)|([0-9]{2,4})[ -]?)*?[0-9]{3,4}[ -]?[0-9]{3,4}$/;

const checkoutSchema = yup.object().shape({
  firstName: yup.string().required("required"),
  lastName: yup.string().required("required"),
  email: yup.string().email("invalid email").required("required"),
  contact: yup
    .string()
    .matches(phoneRegExp, "Phone number is not valid")
    .required("required"),
  address1: yup.string().required("required"),
  address2: yup.string().required("required"),
});
const initialValues = {
  firstName: "",
  lastName: "",
  email: "",
  contact: "",
  address1: "",
  address2: "",
};

export default Form;
